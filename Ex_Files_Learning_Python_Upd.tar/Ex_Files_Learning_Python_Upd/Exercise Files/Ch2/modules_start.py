# import the math module, which contains features for working with mathematics


# the math module contains lots of pre-built functions


# in addition to functions, some modules contain useful constants


# try some of the math functions for yourself here:
